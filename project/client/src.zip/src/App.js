import Main from "./components/Main";
import "./App.css";
import React from "react";
import Clinic from "./components/Clinic";
import HelloWorld from "./components/HelloWorld";

function App() {
  return (
      <Main/>
  );
}

export default App;
