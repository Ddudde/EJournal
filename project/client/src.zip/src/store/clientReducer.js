import {CHANGE_CLIENT} from './actions';

const initialState = {
        "clients": []
    };

export default function clientReducer(state = initialState, action) {
    console.log('reducer', state, action);
    switch(action.type) {
        case CHANGE_CLIENT:
            return {
                    "clients": action.payload
                };
        default:
            return state;
    }
}