export const CHANGE_CHECKBOX = "CHANGE_CHECKBOX";
export const CHANGE_CLIENT = "CHANGE_CLIENT";

export function change_CB(checkbox_id, checkBoxState) {
    return { type: CHANGE_CHECKBOX,
        payload: {
            checkBoxId: checkbox_id,
            checkBoxState: !checkBoxState
        }
    };
}

export function change_CL(body) {
    return {
        type: CHANGE_CLIENT, payload: body
    };
}