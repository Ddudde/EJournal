import { combineReducers } from "redux";
import checkBoxReducer from "./checkBoxReducer";
import clientReducer from "./clientReducer";

export default combineReducers({
    checkbox: checkBoxReducer,
    client: clientReducer
});