export const all = state => state
export const clients = state => state.client || {"clients":[]};

export function getCheckBoxState(checkbox_id, checkbox_state) {
    return state =>
        state.checkbox[checkbox_id] ||
        checkbox_state ||
        false;
}